﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExpenseTracker.Models
{
    public class ExpensesContextDb:DbContext
    {
        public ExpensesContextDb(DbContextOptions<ExpensesContextDb> options) : base(options)
        {
        }
        public DbSet<ExpenseCategory> ExpenseCategorys { get; set; }
        public DbSet<Expense> Expenses { get; set; }
    }
}
