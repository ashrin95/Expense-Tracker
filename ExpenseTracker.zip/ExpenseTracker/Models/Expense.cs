﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ExpenseTracker.Models
{
    public class Expense
    {
        [Key]
        public int ExpensesId { get; set; }
        public DateTime DateOfExpense { get; set; }
        [Required(ErrorMessage = "This field is required!")]
        public decimal ExpenseAmount { get; set; }
        public int ExpenseCategoryId { get; set; }
        public ExpenseCategory ExpenseCategory { get; set; }
    }
}
