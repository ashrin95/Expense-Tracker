﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ExpenseTracker.Models
{
    public class ExpenseCategory
    {
        [Key]
        public int CategoryId { get; set; }
              
        [Remote("ExpenseCategoriesExists", "ExpenseCategories", HttpMethod = "POST", ErrorMessage = "Expense Category already exists in database.")]
        public string CategoryName { get; set; }
        public ICollection<Expense> Expenses { get; set; }
    }
}
